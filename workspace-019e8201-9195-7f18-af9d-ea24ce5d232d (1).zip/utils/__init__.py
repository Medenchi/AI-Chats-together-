# Helper utilities
